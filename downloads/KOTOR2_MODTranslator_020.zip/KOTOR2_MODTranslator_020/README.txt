KOTOR II MOD 汉化工作台 0.2.0

运行 KOTOR2_MOD汉化工作台.exe，无需安装Python。选择“MOD汉化”或“原版文本修正”，提取后手动/CSV/AI翻译，最后打包独立MOD。夹克名称和说明直接在物品文件里，不需要选原文文本表。

API 设置由用户自行填写兼容服务地址、模型与密钥。原文发送至你选择的服务，可能按服务商规则计费。密钥默认仅会话使用，可按Windows用户加密保存；不会进入工程或MOD。

教程：https://francisagust198.github.io/kotor2-chinese-localization/mod-translation.html
仓库：https://github.com/francisagust198/kotor2-chinese-localization

支持松散GFF和已有编号TLK修正；容器/脚本/2DA等未自动处理。AI稿与实际游戏显示需要复核。新工具最后的布局调整尚未重新截图验收。
